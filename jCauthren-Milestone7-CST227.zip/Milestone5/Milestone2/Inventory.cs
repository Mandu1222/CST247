﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone2
{
    public class Inventory
    {
        public String IDNumber { get; set; } = "none";
        public String Name { get; set; } = "none";
        public double Price { get; set; } = 0.0;
        public DateTime CreationDate { get; set; } = System.DateTime.Now;
        public double Stock { get; set; } = 0.0;

        public Inventory() { }

        public String InventoryString()
        {
            return ("ID: " + IDNumber + " " + Name + " Created: " + CreationDate.ToShortDateString() +
                " Stock: " + Stock.ToString() + "\n Price: $" + Price);

        }
    }
}
