﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone2
{
    public class InventoryManager
    {
        public List<Inventory> InventoryList = new List<Inventory>();

        public InventoryManager() { }

        public int searchByID(string ID)
        {
            for (int i = 0; i < InventoryList.Count; i++)
            {
                if (ID == InventoryList[i].IDNumber)
                {
                    return i;
                }
            }
            return -1;
        }
    }
}
