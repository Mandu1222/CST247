﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone2
{
    public partial class InventoryList : Form
    {
        public InventoryList(string memInvList)
        {
            InitializeComponent();
            txtList.Text = memInvList;
        }

        private void txtList_TextChanged(object sender, EventArgs e)
        {

        }

        private void InventoryList_Load(object sender, EventArgs e)
        {

        }
    }
}
