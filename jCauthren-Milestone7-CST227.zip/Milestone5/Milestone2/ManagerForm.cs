﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone2
{
    public partial class ManagerForm : Form
    {
        public string memID = "";
        public String memList = "";

        public InventoryManager myInventory = new InventoryManager();

        public ManagerForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            IDForm frmInventoryID = new IDForm();
            frmInventoryID.ShowDialog();

            int memCIndex = myInventory.searchByID(frmInventoryID.memID);
            if (memCIndex == -1)
            {
                MessageBox.Show("Item not on file.  Try a different ID.");
                return;
            }

            DialogResult memYN = MessageBox.Show(myInventory.InventoryList[memCIndex].InventoryString(), "Remove this Item?  [Y/N]", MessageBoxButtons.YesNo);
            if (memYN != DialogResult.Yes)
            {
                MessageBox.Show("Item not removed.");
            }
            else
            {
                myInventory.InventoryList.RemoveAt(memCIndex);
                MessageBox.Show("Item has been removed.");
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            IDForm frmInventoryID = new IDForm();
            frmInventoryID.ShowDialog();
            string memID = frmInventoryID.memID;

            if (myInventory.searchByID(memID) != -1)
            {
                MessageBox.Show("ID already taken.  Try a different ID.");
                return;
            }
            InventoryEntry frmEntry = new InventoryEntry();
            frmEntry.memID = memID;
            frmEntry.memName = "";
            frmEntry.memPrice = 0.0;
            frmEntry.memCDate = System.DateTime.Now;
            frmEntry.memPrice = 0.0;
            frmEntry.memStock = 0.0;
            frmEntry.ShowDialog();

            Inventory c = new Inventory();
            c.IDNumber = frmEntry.memID;
            c.Name = frmEntry.memName;
            c.Price = frmEntry.memPrice;
            c.Stock = frmEntry.memStock;
            c.CreationDate = frmEntry.memCDate;
            myInventory.InventoryList.Add(c);
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            IDForm frmInventoryID = new IDForm();
            frmInventoryID.ShowDialog();

            int memCIndex = myInventory.searchByID(frmInventoryID.memID);
            if (memCIndex == -1)
            {
                MessageBox.Show("Item not on file.  Try a different ID.");
                return;
            }

            InventoryEntry frmEntry = new InventoryEntry();

            frmEntry.memID = frmInventoryID.memID;
            frmEntry.memName = myInventory.InventoryList[memCIndex].Name;
            frmEntry.memCDate = myInventory.InventoryList[memCIndex].CreationDate;
            frmEntry.memPrice = myInventory.InventoryList[memCIndex].Price;
            frmEntry.memStock = myInventory.InventoryList[memCIndex].Stock;

            frmEntry.Show();

            Inventory i = new Inventory();
            i.IDNumber = frmEntry.memID;
            i.Name = frmEntry.memName;
            i.CreationDate = frmEntry.memCDate;
            i.Price = frmEntry.memPrice;
            i.Stock = frmEntry.memStock;
            myInventory.InventoryList.Add(i);
            myInventory.InventoryList.RemoveAt(memCIndex);
        }

        private void btnListAll_Click(object sender, EventArgs e)
        {
            String memList = "";
            for (int c = 0; c < myInventory.InventoryList.Count; c++)
            {
                memList += "ID: " + myInventory.InventoryList[c].IDNumber + " Name " +
                    myInventory.InventoryList[c].Name + Environment.NewLine;
            }
            InventoryList lstForm = new InventoryList(memList);
            lstForm.ShowDialog();
        }

        private void FindBy_Click(object sender, EventArgs e)
        {
            NameForm frmName = new NameForm();
            frmName.ShowDialog();
            try
            {
                string memName = frmName.ReturnName;
                String memList = "";
                for (int i = 0; i < myInventory.InventoryList.Count; i++)
                {
                    if (memName == myInventory.InventoryList[i].Name)
                    {
                        memList += "ID: " + myInventory.InventoryList[i].IDNumber + " Name " +
                            myInventory.InventoryList[i].Name + Environment.NewLine;
                    }
                }
                InventoryList lstForm = new InventoryList(memList);
                lstForm.ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show("Not a valid entry");
            }

        }

        private void FindPrice_Click(object sender, EventArgs e)
        {
            PriceForm frmPrice = new PriceForm();
            frmPrice.ShowDialog();

            try
            {

                double memPrice = Convert.ToDouble(frmPrice.ReturnPrice);
                String memList = "";
                for (int i = 0; i < myInventory.InventoryList.Count; i++)
                {
                    if (memPrice == myInventory.InventoryList[i].Price)
                    {
                        memList += "ID: " + myInventory.InventoryList[i].IDNumber + " Name " +
                            myInventory.InventoryList[i].Name + Environment.NewLine;
                    }
                }
                InventoryList lstForm = new InventoryList(memList);
                lstForm.ShowDialog();
            }
            catch (Exception) 
            {
                MessageBox.Show("Not a valid entry");
            }
        }
    }
}
