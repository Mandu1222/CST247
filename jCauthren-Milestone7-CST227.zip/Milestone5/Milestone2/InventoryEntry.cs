﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone2
{

    public partial class InventoryEntry : Form
    {
        public string memID;
        public string memName;
        public double memPrice;
        public double memStock;
        public bool valid = true;
        public DateTime memCDate;

        public InventoryEntry()
        {
            InitializeComponent();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            errStock.Visible = false;
            errID.Visible = false;
            errName.Visible = false;
            errPrice.Visible = false;

            if (txtID.Text == "")
            {
                MessageBox.Show("Cannot add a blank ID. Exiting Add.");
                valid = false;
                this.Close();
            }

            if (valid == false)
            {
                return;
            }

            if (txtName.Text == "")
            {
                valid = false;
                errName.Visible = true;
            }

            if (txtPrice.Text == "")
            {
                valid = false;
                errPrice.Visible = true;
            }
            else
            {
                if (double.TryParse(txtPrice.Text, out memPrice))
                {
                    if (memPrice < 0.0)
                    {
                        valid = false;
                        errPrice.Visible = true;
                    }
                    else { }
                }
                else
                {
                    valid = false;
                    errPrice.Visible = true;
                }
            }

            if (txtStock.Text == "")
            {
                valid = false;
                errStock.Visible = true;
            }
            else
            {
                if (double.TryParse(txtStock.Text, out memStock))
                {
                    if (memStock < 0.0)
                    {
                        valid = false;
                        errStock.Visible = true;
                    }
                    else { }
                }
                else
                {
                    valid = false;
                    errStock.Visible = true;
                }
            }

            if (!valid)
            {
                MessageBox.Show("There are errors in the data entered.  Please correct the fields with ** on the left.");
                return;
            }
            else
            {
                MessageBox.Show("Item has been validated.");
                memID = txtID.Text;
                memName = txtName.Text;
                double.TryParse(txtPrice.Text, out double memPrice);
                memCDate = DateTime.Parse(txtCreationDate.Text);
                double.TryParse(txtStock.Text, out double memStock);
                MessageBox.Show("ID: " + memID + ", " + memName + ", $" + memPrice.ToString() + ", Made on " + memCDate.ToShortDateString() + ", Stock: " + memStock.ToString());
                this.Close();
            }
        }

        private void InventoryEntry_Load(object sender, EventArgs e)
        {
            txtID.Text = memID;
            txtStock.Text = memStock.ToString();
            txtName.Text = memName;
            txtPrice.Text = memPrice.ToString();
            txtCreationDate.Text = memCDate.ToShortDateString();
            this.Refresh();
        }
    }
}
